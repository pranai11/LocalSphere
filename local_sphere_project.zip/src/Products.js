import React from 'react'
import Header from './Header'
import Footer from './Footer'

const Products = () => {
  return (
    <div>
      <Header/>  
<head>
  
  <title>Document</title>
</head>
<body>
  <div class="hello">
    <div class="left">
      <h2><b>Service Reviews</b></h2>
      <p ><h1>Let your brand join the </h1></p>
        <p >conversation</p><br/>
        <p >Collecting reviews on Local Sphere gives your current and </p>
          <p> future customers a place to learn about fellow shoppers</p> 
          <p>experiences with your business.</p><br/><br/>
          <button class="button1" type="button">Get a Demo</button>

    </div>

    <div class="right">
      <img src="https://images.ctfassets.net/b7g9mrbfayuu/616AnAiUcIpDSlZh1vytj1/d4a35913ec3c7993cc78697098811667/Service_reviews-_Jumbotron.png?q=80&w=828&fm=webp" alt=""/>

    </div>
  </div>
  <div class="two">
    <h3><p class="twotext"><b>Did you Know?</b></p></h3><br/>
    <h1 class="twotext1"><p>Verified reviews from Local Sphere count toward </p>
    <p class="twotext1">your Google Seller Rating.</p></h1><br/><br/>
    <a class="twotext1" href="Seller ratings boost CTR on your Google ads by up to 10%">Seller ratings boost CTR on your Google ads by up to 10%</a>

  </div>
  <div class="hello1">
    <div class="left1">
      <h2><b>Service Reviews</b></h2>
      <h1><p>Let your brand join the </p>
        <p>conversation</p></h1><br/>
        <p>Collecting reviews on Local Sphere gives your current and </p>
          <p> future customers a place to learn about fellow shoppers</p> 
          <p>experiences with your business.</p><br/><br/>
          <button class="button1" type="button">Get a Demo</button>

    </div>

    <div class="right1">
      <img src="https://images.ctfassets.net/b7g9mrbfayuu/3sJonz2XsKVMXYLwf7I4S5/fdb9756eaf4e53608a7bb36541e3b9e9/2-Be_discovered_-_Service_reviews_page.png?q=80&w=828&fm=webp" alt=""/>

    </div>
  </div>
  <div class="two">
    <h3><p class="twotext"><b>Did you Know?</b></p></h3><br/>
    <h1 class="twotext1"><p>Verified reviews from Local Sphere count toward </p>
    <p class="twotext1">your Google Seller Rating.</p></h1><br/><br/>
    <a class="twotext1" href="Seller ratings boost CTR on your Google ads by up to 10%">Seller ratings boost CTR on your Google ads by up to 10%</a>

  </div>
  <div class="hello">
    <div class="left">
      <h2><b>Service Reviews</b></h2>
      <p ><h1>Let your brand join the </h1></p>
        <p >conversation</p><br/>
        <p >Collecting reviews on Local Sphere gives your current and </p>
          <p> future customers a place to learn about fellow shoppers</p> 
          <p>experiences with your business.</p><br/><br/>
          <button class="button1" type="button">Get a Demo</button>

    </div>
    <div class="right">
      <img src="https://images.ctfassets.net/b7g9mrbfayuu/616AnAiUcIpDSlZh1vytj1/d4a35913ec3c7993cc78697098811667/Service_reviews-_Jumbotron.png?q=80&w=828&fm=webp" alt=""/>

    </div>
    </div>
</body>
<Footer/>
    </div>
  )
}

export default Products